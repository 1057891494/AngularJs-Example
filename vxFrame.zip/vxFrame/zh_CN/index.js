vxApp.controller("index_setup",["$scope","$state",function($scope,$state){
	$scope.goto=function(state){
 		$state.go(state);
 	};
}]);

/*
 * sessionStorage 属性允许你访问一个 session Storage 对象。
 * 它与 localStorage 相似，不同之处在于 localStorage 里面存储的数据没有过期时间设置，
 * 而存储在 sessionStorage 里面的数据在页面会话结束时会被清除。
 * 页面会话在浏览器打开期间一直保持，并且重新加载或恢复页面仍会保持原来的页面会话。
 * 在新标签或窗口打开一个页面会初始化一个新的会话，这点和 session cookie 的运行方式不同。
 */