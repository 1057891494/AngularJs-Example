vxApp.register.controller("useServiceCtrl",["$scope","$_local",function($scope,$_local){
	$scope.doIt=function(){
		console.log("来自配置服务："+$_local.info);
	};
}]);