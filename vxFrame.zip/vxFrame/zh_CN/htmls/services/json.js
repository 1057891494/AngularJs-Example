vxApp.register.controller("jsonCtrl",["$scope","$jsonService",function($scope,$jsonService){
	$scope.doIt=function(){
			$scope.dataList=new Array(1000);
	};
}]);