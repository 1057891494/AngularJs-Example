$(function(){
	console.warn("第一项：DOM对象和jQuery对象之间互相转换。");
	//DOM get
	var domElem=document.getElementById("jQueryDom");
	//Jquery get
	var JqueryElem=$("#jQueryDom");

	//Jquery --> DOM 1
	var newDomeElemOne=JqueryElem[0];
	console.info("//Jquery --> DOM 1",newDomeElemOne.innerHTML);

	//Jquery --> DOM 2
	var newDomeElemTwo=JqueryElem.get(0);
	console.info("//Jquery --> DOM 2",newDomeElemTwo.innerHTML);

	//DOM --> Jquery
	var newJqueryElem=$(domElem);
	console.info("//DOM --> Jquery",newJqueryElem.html());
	
	//$("#loadMethod").load("htmls/jQuery/other.html");
	//console.log(document.getElementById("#loadMethod"));//.load("htmls/jQuery/other.html");
	
	var xmlhttp;
	if (window.XMLHttpRequest)
	{
		//  IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		// IE6, IE5 浏览器执行代码
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			document.getElementById("loadMethod").innerHTML=xmlhttp.responseText;
		}
	};
	xmlhttp.open("GET","htmls/jQuery/other.html",true);
	xmlhttp.send();
});

$(function(){
	console.warn("第二项：理解Jquery。");
	console.log($);
	console.log(jQuery.noConflict());
	console.log($,jQuery);
	jQuery.noConflict();
	console.log($,jQuery);
	window.$=jQuery;
	console.log($);
});

$(function(){
	console.warn("第三项：练习Jquery DOM操作。");
	//console.log($);
	$("ul li:eq(1)").appendTo("ul");//移动位置
	$("ul li").on("click",function(){
		console.log("click "+$(this).text());
		$(this).clone(true).appendTo("ul");//复制元素，true会完全复制，无true不会复制行为
	});
	var $lis=$("ul li");
	var i;
	for(i=0;i<$lis.length;i++){
		console.log($($lis[i]).attr("title"));
	}
});

$(function(){
	console.warn("第四项：练习Jquery class操作。");
	console.log($("ul").attr("class"));
	$("ul").addClass("beforeNew addClass");//需要注意的是，css的顺序是按照定义的顺序，不是class的顺序
	console.log($("ul").attr("class"));
	//$("ul").attr("class","newClass");
	//console.log($("ul").attr("class"));
});

$(function(){
	console.warn("第五项:选择问题。");
	$("#select").val(["value3","value2"]);
});

$(function(){
	console.warn("第六项:定义插件提前练习。");
	var obj1={
		name:"tom",
		color:"red"
	};
	var obj2=$.extend({
		color:"blue",
		age:17
	},obj1);
	console.log(obj2);

	//使用自定义插件
	//console.log($("#showColor").color());
	console.log($("#showColor").color("yellow"));
	console.log($("#showColor").color());
	console.info($("p"));
	console.info($("p:between(1,2)"));
	$("p:between(1,2)").color("red");
});