vxApp.register.controller("localStorageCtrl",["$scope","$cookieService","$localStorage","$sessionStorage",function($scope,$cookieService,$localStorage,$sessionStorage){
	$scope.startUp=function(){
		var _json={
			"name":"tom",
			"age":"12"
		};
		localStorage.setItem('loginInfo', "localStorageInfo");
		// 保存数据json到sessionStorage
		sessionStorage.setItem('key', JSON.stringify(_json));
		// 保存数据到sessionStorage
		sessionStorage.setItem('name', "yelloxing");
		
		
		
	};
	$scope.showJson=function(){
		console.log("localStorage:",localStorage.getItem('loginInfo'));
		// 从sessionStorage获取数据
		var data = sessionStorage.getItem('key');
		console.log("sessionStorage:",data);
		console.log(JSON.parse(data));
		console.log(sessionStorage.getItem('name'));
	};
	$scope.addCke=function(){
		var _json={
			"name":"tom",
			"age":"12"
		};
		//document.cookie="yelloxing@gmail.com";
		//document.cookie=JSON.stringify(_json);
		$cookieService.addCookice("userId","Tom",0.5);
		$cookieService.addCookice("pwd","123456789",1);
	};
	$scope.delCke=function(){
		//通过设置过期时间就可以 了
		$cookieService.deleteCookie("userId");
	};
	$scope.updateCke=function(){
		document.cookie="kapok@gmail.com";
	};
	$scope.getCke=function(){
		//console.info(JSON.parse(document.cookie));
		console.log($cookieService.getCookie("userId"),0.5);
		console.log($cookieService.getCookie("pwd"),1);
	};
	
	/*
	 * localStorage
	 */
	
	//增加或修改localStorage
	$scope.addLS=function(){
		//localStorage.setItem('loginInfo', "localStorageInfo");
		//localStorage.setItem('pwd', "123456");
		$localStorage.addStorage('pwd', "123456");
		$localStorage.addStorage('loginInfo', "localStorageInfo");
	};
	$scope.delLS=function(){
			//删除localStorage中存储信息的方法：
			//localStorage.removeItem("key");//删除名称为“key”的信息。
			//localStorage.clear();
			//清空localStorage中所有信息
			//localStorage.removeItem("loginInfo");
			$localStorage.deleteStorage("pwd");
	};
	$scope.getLS=function(){
		//console.log(localStorage.getItem('pwd'));
		console.log($localStorage.getStorage("pwd"));
		console.log($localStorage.getStorage("loginInfo"));
	};
	//增加或修改sessionStorage
	$scope.addSS=function(){
		//localStorage.setItem('loginInfo', "localStorageInfo");
		//localStorage.setItem('pwd', "123456");
		$sessionStorage.addStorage('pwd', "123456");
		$sessionStorage.addStorage('loginInfo', "localStorageInfo");
	};
	$scope.delSS=function(){
			//删除localStorage中存储信息的方法：
			//localStorage.removeItem("key");//删除名称为“key”的信息。
			//localStorage.clear();
			//清空localStorage中所有信息
			//$sessionStorage.removeItem("loginInfo");
			$sessionStorage.deleteStorage();
	};
	$scope.getSS=function(){
		//console.log(localStorage.getItem('pwd'));
		console.log($sessionStorage.getStorage("pwd"));
		console.log($sessionStorage.getStorage("loginInfo"));
	};
	
}]);

/*
 sessionStorage只会保存一个会话时间长度
 localStorage可以在关闭会话再打开时已经存在
 * */
