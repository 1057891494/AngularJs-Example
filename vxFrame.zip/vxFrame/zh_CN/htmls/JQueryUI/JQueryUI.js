$( "#date" ).datepicker();
$( "#elem" ).progressbar();

//-------------------


/*
 * 定义widget
 */
$.widget( "custom.progressbar", {
 
    options: {
        value: 0
    },
 
    _create: function() {
        var progress = this.options.value + "%";
        this.element
            .addClass( "progressbar" )
            .text( progress );
    },
 
    // Create a public method.
    value: function( value ) {
 
        // No value passed, act as a getter.
        if ( value === undefined ) {
            return this.options.value;
        }
 
        // Value passed, act as a setter.
        this.options.value = this._constrain( value );
        var progress = this.options.value + "%";
        this.element.text( progress );
    },
 
    // Create a private method.
    _constrain: function( value ) {
        if ( value > 100 ) {
            value = 100;
        }
        if ( value < 0 ) {
            value = 0;
        }
        return value;
    }
});





/*
 * 使用widget
 */
var bar = $( "<div></div>" )
    .appendTo( "body" )
    .progressbar({ value: 20 });
 
// Get the current value.
console.error( bar.progressbar( "value" ) );
 
// Update the value.
bar.progressbar( "value", 50 );
 
// Get the current value again.
console.error( bar.progressbar( "value" ) );


//-----------练习widget
$.widget("custom.myDialog",$.ui.dialog,{
	red:function(){
		this.element.css("color","red");
	},
	open:function(){
		console.log("由于重新写了一下open的方法，因此对话框不会再显示在window上了，open会默认被调用的。");
		return this._super();
	}
});

$("#myWidget").myDialog();
$("#myWidget").myDialog("red");

//----------练习JQueryUI的API
$("#addClass").click(function(){
	$(this).addClass("addClass",1000,"easeOutBounce",function(){
		console.log("动画结束！！！");
	});
});
