vxApp.register.controller("HighchartsCtrl",["$scope",function($scope){
	$scope.startUp=function(){
		



var chart = {
   type: 'line'
};
   var title = {
       text: '标题'   
   };
   var subtitle = {
        text: '子标题'
   };
   var xAxis = {
       categories: ['一月', '二月', '三月', '四月', '五月', '六月'
              ,'七月', '八月', '九月', '十月', '十一月', '十二月']
   };
   var yAxis = {
      categories: ['0', '1', '2', '3', '4', '5'
      ,'6', '7', '8', '9', '10', '11','12']
   };   

   var tooltip = {
      valueSuffix: '000'
   };

   var legend = {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 10
   };

   var series =  [
      {
         name: 'London',
         data: [0.9, 4.2, 5.7, 8.5, 11.9, 10.2, 11.0, 
            11.6, 11.2, 10.3, 6.6, 4.8]
      }
   ];
   var credits={
   		enabled:false
   };
   var json = {};

	json.chart=chart;
   json.title = title;
   json.subtitle = subtitle;
   json.xAxis = xAxis;
   json.yAxis = yAxis;
   json.tooltip = tooltip;
   json.legend = legend;
   json.series = series;
   json.credits=credits;

   $('#container').highcharts(json);
   	};
}]);
