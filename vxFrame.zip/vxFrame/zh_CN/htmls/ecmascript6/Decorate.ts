function addMethod(target){
	target.getInfo=function(){
		console.log("getInfo()");
	};
}

@addMethod
class Js{
	
}

Js.getInfo();