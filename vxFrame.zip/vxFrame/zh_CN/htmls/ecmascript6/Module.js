import {getTime} from './tool';

console.log(getTime());