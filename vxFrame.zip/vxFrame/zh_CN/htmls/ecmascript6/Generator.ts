function* generatorHelloWorld(){
	console.log(yield "state001");
	console.log(yield "state002");
	return "return-state";
}

var iteGenerator=generatorHelloWorld();
console.log(iteGenerator.next(1));
console.log(iteGenerator.next(2));//记住，next带的是上一次yield返回的值，这次调用带过去
console.log(iteGenerator.next(3));
console.log(iteGenerator.next(4));

