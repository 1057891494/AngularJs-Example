class Demo{
	constructor(flag){
		this.flag=flag;
	}
	toString(){
		return "My flag is "+this.flag;
	}
}

let demo =new Demo("这只是一个flag");
console.log(demo.toString());


let person=new class Person{
/*
上面的Person可以不写
this代表的是对象，Person代表的是类
*/
	constructor(name){
		this.name=name
	}
	toString(){
		return this.name+"---"+Person.name;
	}
}("56");

console.log(person.toString());


//继承

class Father{
	constructor(name){
		this.name=name;
	}
}

class Son extends Father{
	constructor(name){
		//this.name=name;
		super();//这个super是必须的
		this.name=name;
	}//构造器 不写会继承父亲的

	/*
	set name(name){
		console.log("setter:"+name);
		this.name=name;
	}
	get name(){
		cosole.log("getter:"+this.name);
		return "==="+this.name;
	}
	*/
}

let son =new Son("名称");
console.log(son.name);
//son.name="new name";

/**
在继承上面
5和6的一个重要区别是：
5是子类先创建好对象，然后把父类的对象复制过来
6是先创建好父类对象，然后感觉子类class的定义，修改一下变成子类对象
*/

//5中，__proto__指向的是创建了这个对象的类的原型prototype



class MyClass {
  constructor() {
    // ...
  }
  get prop() {
    return 'getter';
  }
  set prop(value) {
     console.log('setter: '+value);
  }
  //static age=9;//7提案支持
}

let inst = new MyClass();

inst.prop = 123;
// setter: 123

console.log(inst.prop);
// 'getter”


class F{
	constructor(){
		console.log(new.target==F);
	}
}
class S extends F{
	
}

new S();
new F();














