var set=new Set();
[1,2,4,3,7,6,6,2,1].map(x=>set.add(x));
for(let val of set){
	console.log(val);
}

console.log(...set);

var arr=[0,45,2,2,42,4,"2rwr"];
console.debug(...arr);

let metSet=new Set();

metSet.add(2);
metSet.add(5).add("yello").add(1);

console.log(...metSet);

console.log(metSet.has(1));

metSet.delete(1);

console.log(...metSet);

console.log(metSet.has(1));

metSet.clear();
console.log(metSet.size);

metSet.add("butterfly").add("-wifi").add(254896).add("wifi");
for(let key of metSet.keys()){
	console.error(key);
}
for(let val of metSet.values()){
	console.debug(val);
}
for(let entry of metSet.entries()){
	console.info(entry);
}
metSet.forEach(function(data){
	console.warn(data);
});

console.log(arr);

var newArr=arr.filter(function(data){
	return data>7;
});

console.log(newArr);

var arrSet=new Set([1,2,4,[4,3,7,8]]);
console.log(...arrSet);

/*
============下面是WeakSet
*/
var weakArr=[[1,2],[3,2]];
let arrWeakSet=new WeakSet(weakArr);
console.log(arrWeakSet);

console.error("========================下面是map");

var map=new Map([["name","名字"],["age","年龄"]]);
console.log(map.has("name"),map.get("age"));

let obj=["newObj"];
map.set(obj,"你应该拿不到这个数据,除非同一个对象");
console.log(map.get(["newObj"]));
console.log(map.get(obj));
































