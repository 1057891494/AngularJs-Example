var int8View=new Int8Array(1);
int8View[0]=128;
console.log(int8View[0],int8View.byteLength,int8View.byteOffset);

var arrayBuffer=new ArrayBuffer(4);

var int16Array=new Int16Array(arrayBuffer,2,1);

console.log(int16Array.byteLength,int16Array[0],int16Array.byteOffset,int16Array.length);

var int8ViewA=new Int8Array(1);
var int8ViewB=new Int8Array(1);
int8ViewA[0]=70;
console.log(int8ViewA,int8ViewB);
int8ViewB.set(int8ViewA);
console.log(int8ViewA,int8ViewB);

let float32View=Float32Array.of(17,99,98);
console.log(float32View);
let new32View=float32View.slice(0,2);
console.log(float32View,new32View);


