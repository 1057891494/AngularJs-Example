let dataList=["cctv","btv","mtv","ufo","iso8859-1",-1];

let ite=dataList[Symbol.iterator]();
let result=ite.next();
while(!result.done){
	console.error(result.value);
	result=ite.next();
}

var noIterator={
	"name":"名称",
	"age":"年龄",
	"sex":"性别",
	"info":"信息"
};

//for(let val of noIterator){
//	console.warn(val);
//}

for(let key in noIterator){
	console.warn(key);
}
//console.log(key);
for(let key of Object.keys(noIterator)){
	console.log(key);
}
/*
为自己的对象提供一个自定义的迭代器方法
当然你也可以为『类』准备，这无关紧要，看需求而定
*/
noIterator[Symbol.iterator]=function(){
	return {
		"next":(function(){
			var flag=0;
			return function(){
				switch(flag){
					case 0:{
						flag++;
						return {"value":noIterator["name"],"done":false};
					}
					case 1:{
						flag++;
						return {"value":noIterator["age"],"done":false};
					}
					case 2:{
						flag++;
						return {"value":noIterator["sex"],"done":false};
					}
					case 3:{
						flag++;
						return {"value":noIterator["info"],"done":false};
					}
					default:{
						return {"value":undefined,"done":true};
					}
				}
			};
		})()
	};
};

console.log(...noIterator);

for(let val of noIterator){
	console.warn(val);
}

for(let index in noIterator){
	console.debug(index);
}

//var keyValues=noIterator.entries();
//for(let node of keyValues){
//	console.log(node);
//}

for(let key of Object.keys(noIterator)){
	console.log(key);
}
/*
Object对象的keys方法可以获取对象的键
*/










