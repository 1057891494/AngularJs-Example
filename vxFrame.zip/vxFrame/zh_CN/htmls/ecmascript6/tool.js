function getTime(){
	return new Date();
}

export {getTime};