app.controller("appController",["$scope",function($scope){
	$scope.username="yelloxing";
}]);
