app.controller("demoController",["$scope",function($scope){
	$scope.startUp=function(){
		console.info("ui-view");
	};
}]);
