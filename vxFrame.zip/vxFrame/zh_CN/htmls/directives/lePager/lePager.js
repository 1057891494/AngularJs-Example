vxApp.register.controller("lePagerCtrl",["$scope",function($scope){
	$scope.startUp=function(){
		console.log("分页指令测试初始化开始！");
		$scope.params={
			pageseq:1,
			pagesize:10
		};
		$scope.submit();
		console.log("分页指令测试初始化结束！");
	};

	$scope.submit=function(){
		var pagesize=$scope.params.pagesize;
		$scope.resultData=$scope.getResultData(1,pagesize);
		$scope.resultData.flag={
			prev:"FALSE",
			next:"TRUE"
		};
	};

	$scope.doQuery=function(pageSeq,pageSize){
		console.log("doQuery被调用了");
		$scope.resultData=$scope.getResultData(pageSeq,pageSize);
		var prevFlag="TRUE",nextFlag="TRUE";
		if(pageSeq==1) prevFlag="FALSE";
		if(pageSeq*pageSize>=$scope.database.length) nextFlag="FALSE";
		$scope.resultData.flag={
			prev:prevFlag,
			next:nextFlag
		};
		
		console.error($scope.resultData.flag);

	};

	//用来帮助获取数据的方法
	$scope.getResultData=function(pageSeq,pageSize){
		var endFlag=pageSeq*pageSize;
		var flag,begFlag=(pageSeq-1)*pageSize;
		console.log(begFlag,endFlag,$scope.database.length);
		var cacheArray=[];
		for(flag=0; flag+begFlag<endFlag && flag+begFlag<$scope.database.length ;flag++){
				cacheArray[flag]=$scope.database[begFlag+flag];
		}
		return cacheArray;
	};

	//用来测试的假数据
	$scope.database=[
		{"NAME":"Alice","AGE":"1","HOBBY":"爱好一","LEGAL":"null——not","INFO":"null——not"},
		{"NAME":"Tom","AGE":"2","HOBBY":"爱好二","LEGAL":"","INFO":"null——not"},
		{"NAME":"Kapok","AGE":"3","HOBBY":"爱好三","LEGAL":"","INFO":"null——not"},
		{"NAME":"Ubli","AGE":"4","HOBBY":"爱好四","LEGAL":"","INFO":"null——not"},
		{"NAME":"eclipes","AGE":"5","HOBBY":"爱好五","LEGAL":"","INFO":"null——not"},
		{"NAME":"edipluds","AGE":"6","HOBBY":"爱好六","LEGAL":"","INFO":"null——not"},
		{"NAME":"mac","AGE":"7","HOBBY":"爱好七","LEGAL":"","INFO":"null——not"},
		{"NAME":"subliem","AGE":"8","HOBBY":"爱好八","LEGAL":"null——not","INFO":"null——not"},
		{"NAME":"oracle","AGE":"9","HOBBY":"null——not","LEGAL":"null——not","INFO":"null——not"},
		{"NAME":"sunrise","AGE":"10","HOBBY":"null——not","LEGAL":"null——not","INFO":"null——not"},
		{"NAME":"opensess","AGE":"11","HOBBY":"null——not","LEGAL":"null——not","INFO":"null——not"},
		{"NAME":"gnu-linux","AGE":"12","HOBBY":"null——not","LEGAL":"","INFO":"null——not"},
		{"NAME":"OpenSUSE","AGE":"13","HOBBY":"null——not","LEGAL":"","INFO":"null——not"},
		{"NAME":"readHat","AGE":"14","HOBBY":"null——not","LEGAL":"","INFO":"null——not"},
		{"NAME":"booy","AGE":"15","HOBBY":"null——not","LEGAL":"","INFO":"null——not"},
		{"NAME":"xysfs","AGE":"16","HOBBY":"null——not","LEGAL":"","INFO":"null——not"},
		{"NAME":"plm_ji","AGE":"17","HOBBY":"null——not","LEGAL":"","INFO":"null——not"},
		{"NAME":"jack","AGE":"18","HOBBY":"null——not","LEGAL":"","INFO":"null——not"},
		{"NAME":"tomss","AGE":"19","HOBBY":"null——not","LEGAL":"","INFO":"null——not"},
		{"NAME":"alobbe","AGE":"20","HOBBY":"null——not","LEGAL":"","INFO":"null——not"},
		{"NAME":"anie","AGE":"21","HOBBY":"null——not","LEGAL":"","INFO":"null——not"},
		{"NAME":"Ending","AGE":"22","HOBBY":"null——not","LEGAL":"null——not","INFO":"null——not"}
	];

}]);