vxApp.register.controller("leFormsCtrl",["$scope",function($scope){
	$scope.startUp=function(){
		
	}
}]);