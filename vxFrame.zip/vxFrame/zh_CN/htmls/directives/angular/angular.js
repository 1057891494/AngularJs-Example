vxApp.register.controller("angularCtrl",["$scope",function($scope){
	$scope.open=function(){
		console.log("看见这个表示ok");
		// $("#elem").bind("touchstart", function(){
		// 	console.error("------");
		// });
	};
}]);