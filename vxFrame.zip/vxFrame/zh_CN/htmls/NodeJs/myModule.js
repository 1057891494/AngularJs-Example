var info="【默认值】";

exports.setInfo=function(data){
	info=data;
};
exports.getInfo=function(){
	return info;
};