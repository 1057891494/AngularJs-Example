var fs=require("fs");
fs.readFile("./sel.txt","utf-8",function(error,data){
	if(error){
		console.log(error);
	}else{
		console.log(data);
	}
});


var myModule=require('./myModule.js');

console.log(myModule.getInfo());
myModule.setInfo("重新设置的info数据！！！");
console.log(myModule.getInfo());


var myPackage=require('./myPackage');
myPackage.get();


console.log(global.process.argv);