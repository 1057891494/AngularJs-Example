vxApp.register.controller("FilterSelfCtrl", ["$scope",
function($scope) {
	$scope.startUp = function() {

	};

	$scope.touStr1 = function(ev) {
		var flag = -1;
		ev = ev || window.event;
		ev=ev.touches[0];
		if (ev.pageX || ev.pageY) {
			flag = ev.pageX;
		}
		flag = ev.clientX + document.body.scrollLeft - document.body.clientLeft;
		console.log(flag, "按下", ev);
	};
	$scope.touStr2 = function(ev) {
		var flag = -1;
		ev = ev || window.event;
		ev=ev.touches[0];
		if (ev.pageX || ev.pageY) {
			flag = ev.pageX;
		}
		flag = ev.clientX + document.body.scrollLeft - document.body.clientLeft;
		console.log(flag, "拖动", ev);
	};
	$scope.touStr3 = function(tar) {
		console.log("松开");
	};
	function getOffsetSum(ele) {
		var top = 0,
		    left = 0;
		while (ele) {
			top += ele.offsetTop;
			left += ele.offsetLeft;
			ele = ele.offsetParent;
		}
		/*  alert(left+" : "+top);*/
		return {
			top : top,
			left : left
		};
	}

}]); 