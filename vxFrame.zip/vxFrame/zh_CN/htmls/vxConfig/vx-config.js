vxApp.register.controller("vxConfigCtrl",["$scope","$remote",
	function($scope,$remote){
		$scope.init=function(){
			$remote.post("info.json",{},function(data){
				console.log(data);
			});
		};
}]);